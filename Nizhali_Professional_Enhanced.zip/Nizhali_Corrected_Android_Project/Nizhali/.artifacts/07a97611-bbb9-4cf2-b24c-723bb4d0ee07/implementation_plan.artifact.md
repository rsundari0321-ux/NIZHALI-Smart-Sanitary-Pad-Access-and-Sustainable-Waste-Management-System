# Fix SSL EOFException during Gradle Sync

The error `java.io.EOFException: SSL peer shut down incorrectly` typically occurs due to network instability or SSL/TLS handshake failures when Gradle attempts to download dependencies or the Gradle distribution itself.

## Proposed Changes

### Build Configuration

#### [MODIFY] [gradle.properties](file:///C:/Users/poo_d/Downloads/Nizhali_Corrected_Android_Project/Nizhali/gradle.properties)
- Add system properties to enforce modern TLS protocols (`TLSv1.2`, `TLSv1.3`).
- Disable HTTP keep-alive to prevent issues with connection reuse that sometimes lead to `EOFException` on certain networks.

#### [MODIFY] [gradle-wrapper.properties](file:///C:/Users/poo_d/Downloads/Nizhali_Corrected_Android_Project/Nizhali/gradle/wrapper/gradle-wrapper.properties)
- Increase the `networkTimeout` to allow more time for downloads on unstable connections.

## Verification Plan

### Automated Tests
- Run `./gradlew prepareKotlinBuildScriptModel` (or sync in Android Studio) to verify that the SSL error no longer occurs.

### Manual Verification
- Confirm that dependencies are successfully downloaded and the project syncs without `EOFException`.
