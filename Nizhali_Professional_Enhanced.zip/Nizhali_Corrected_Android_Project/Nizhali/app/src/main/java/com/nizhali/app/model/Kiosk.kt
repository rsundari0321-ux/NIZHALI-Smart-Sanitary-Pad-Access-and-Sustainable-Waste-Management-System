package com.nizhali.app.model
enum class KioskStatus { OPERATIONAL, LOW_STOCK, MAINTENANCE, OUT_OF_STOCK }
enum class AppLanguage { ENGLISH, TAMIL }
data class Kiosk(val id:String,val nameEn:String,val nameTa:String,val locationEn:String,val locationTa:String,val distanceKm:Double,val status:KioskStatus,val stock:Int,val capacity:Int,val powerHealthy:Boolean){
fun name(lang:AppLanguage)=if(lang==AppLanguage.ENGLISH)nameEn else nameTa
fun location(lang:AppLanguage)=if(lang==AppLanguage.ENGLISH)locationEn else locationTa
}