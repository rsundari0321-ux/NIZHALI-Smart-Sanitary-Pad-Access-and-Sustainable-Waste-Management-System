package com.nizhali.app.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizhali.app.localization.stringsFor
import com.nizhali.app.model.Kiosk
import com.nizhali.app.state.AppViewModel
import com.nizhali.app.ui.theme.SandBackground
import kotlin.math.roundToInt

/**
 * A lightweight in-app navigation emulation. It intentionally does not require a
 * Google Maps API key or network connection, so the project can be demonstrated
 * reliably during the prototype stage.
 */
@Composable
fun DirectionsMapScreen(vm: AppViewModel, id: String, onBack: () -> Unit) {
    val kiosk = vm.kioskById(id) ?: return
    val s = stringsFor(vm.language)
    val minutes = maxOf(2, (kiosk.distanceKm * 8).roundToInt())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SandBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        OutlinedButton(onClick = onBack) { Text("← ${s.back}") }
        Spacer(Modifier.height(12.dp))
        Text("Directions", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("வழிகாட்டுதல்", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(360.dp)
            ) {
                SimulatedMap(kiosk)
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp),
                    shape = RoundedCornerShape(14.dp),
                    tonalElevation = 6.dp
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text("● Your location", fontWeight = FontWeight.Bold)
                        Text("📍 ${kiosk.name(vm.language)}", fontWeight = FontWeight.Bold)
                    }
                }
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🚶", fontSize = 26.sp)
                        Column {
                            Text("${kiosk.distanceKm} km", fontWeight = FontWeight.Bold)
                            Text("Approx. $minutes min")
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Route to ${kiosk.name(vm.language)}", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("1. Start from your current location")
                Text("2. Follow the highlighted route")
                Text("3. Destination: ${kiosk.location(vm.language)}")
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Prototype navigation map — route shown for simulation purposes.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SimulatedMap(kiosk: Kiosk) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        // Background blocks / green areas
        drawRect(Color(0xFFE9E5DD))
        drawCircle(Color(0xFFD6E8D5), radius = size.minDimension * 0.26f, center = Offset(size.width * .18f, size.height * .25f))
        drawCircle(Color(0xFFD6E8D5), radius = size.minDimension * 0.20f, center = Offset(size.width * .82f, size.height * .72f))

        // Roads
        val road = Color.White
        val roadStroke = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Round)
        drawLine(road, Offset(size.width * .08f, size.height * .84f), Offset(size.width * .90f, size.height * .18f), style = roadStroke)
        drawLine(road, Offset(size.width * .18f, size.height * .10f), Offset(size.width * .76f, size.height * .88f), style = roadStroke)
        drawLine(road, Offset(size.width * .02f, size.height * .48f), Offset(size.width * .98f, size.height * .52f), style = roadStroke)

        // Navigation route
        val routeColor = Color(0xFF1976D2)
        val start = Offset(size.width * .20f, size.height * .76f)
        val turn1 = Offset(size.width * .36f, size.height * .61f)
        val turn2 = Offset(size.width * .56f, size.height * .53f)
        val destination = Offset(size.width * .77f, size.height * .30f)
        drawLine(routeColor, start, turn1, strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
        drawLine(routeColor, turn1, turn2, strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
        drawLine(routeColor, turn2, destination, strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)

        // Start marker
        drawCircle(Color(0xFF1565C0), radius = 11.dp.toPx(), center = start)
        drawCircle(Color.White, radius = 4.dp.toPx(), center = start)

        // Destination pin
        drawCircle(Color(0xFFD32F2F), radius = 14.dp.toPx(), center = destination)
        drawCircle(Color.White, radius = 5.dp.toPx(), center = destination)
    }
}
