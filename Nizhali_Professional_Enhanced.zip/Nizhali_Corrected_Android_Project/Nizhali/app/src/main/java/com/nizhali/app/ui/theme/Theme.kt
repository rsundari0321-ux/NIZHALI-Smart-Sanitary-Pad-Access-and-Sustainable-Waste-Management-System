package com.nizhali.app.ui.theme
import androidx.compose.material3.*;import androidx.compose.runtime.Composable;import androidx.compose.ui.graphics.Color
val TealPrimary=Color(0xFF1C7C6B);val TealDark=Color(0xFF0F5346);val TealTint=Color(0xFFE4F1EC);val SandBackground=Color(0xFFF6F5F0);val SurfaceWhite=Color.White;val InkText=Color(0xFF10241D);val MutedText=Color(0xFF5C7269);val StatusAmber=Color(0xFFDB9A34)
private val scheme=lightColorScheme(primary=TealPrimary,onPrimary=SurfaceWhite,background=SandBackground,onBackground=InkText,surface=SurfaceWhite,onSurface=InkText)
@Composable
fun NizhaliTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = scheme,
        content = content
    )
}
