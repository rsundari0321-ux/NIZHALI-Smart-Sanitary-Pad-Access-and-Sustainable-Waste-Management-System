package com.nizhali.app.data
import com.nizhali.app.model.*
object MockData { fun initialKiosks()=listOf(
Kiosk("main_block","Nizhali – Main Block","நிழலி – மெயின் பிளாக்","Main Block","மெயின் பிளாக்",0.8,KioskStatus.OPERATIONAL,24,30,true),
Kiosk("community_centre","Nizhali – Community Centre","நிழலி – சமூக மையம்","Community Centre","சமூக மையம்",1.5,KioskStatus.LOW_STOCK,4,30,true),
Kiosk("bus_stand","Nizhali – Bus Stand","நிழலி – பேருந்து நிலையம்","Bus Stand","பேருந்து நிலையம்",2.3,KioskStatus.MAINTENANCE,0,30,false),
Kiosk("library","Nizhali – Library","நிழலி – நூலகம்","Library","நூலகம்",3.1,KioskStatus.OPERATIONAL,30,30,true),
Kiosk("hostel_block","Nizhali – Girls Hostel","நிழலி – மாணவியர் விடுதி","Girls Hostel","மாணவியர் விடுதி",4.0,KioskStatus.OUT_OF_STOCK,0,30,true)
)}