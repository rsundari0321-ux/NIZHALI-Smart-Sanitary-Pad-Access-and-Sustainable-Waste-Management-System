package com.nizhali.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.nizhali.app.screens.*
import com.nizhali.app.state.AppViewModel
import com.nizhali.app.model.*

object Routes {
    const val SPLASH = "splash"
    const val LANGUAGE = "language"
    const val HOME = "home"
    const val NEARBY = "nearby"
    const val DETAILS = "details/{kioskId}"
    const val DIRECTIONS = "directions/{kioskId}"
    const val FAVORITES = "favorites"
    fun details(id: String) = "details/$id"
    fun directions(id: String) = "directions/$id"
}

@Composable
fun NizhaliNavHost(vm: AppViewModel) {
    val nav = rememberNavController()
    NavHost(nav, Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen { nav.navigate(Routes.LANGUAGE) }
        }
        composable(Routes.LANGUAGE) {
            LanguageSelectionScreen { l ->
                vm.setLanguage(l)
                nav.navigate(Routes.HOME) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            }
        }
        composable(Routes.HOME) {
            HomeScreen(
                vm,
                onFind = { nav.navigate(Routes.NEARBY) },
                onView = { nav.navigate(Routes.details(it)) },
                onLang = { nav.navigate(Routes.LANGUAGE) },
                onFavorites = { nav.navigate(Routes.FAVORITES) }
            )
        }
        composable(Routes.NEARBY) {
            NearbyKiosksScreen(
                vm,
                onClick = { nav.navigate(Routes.details(it)) },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.FAVORITES) {
            FavoritesScreen(vm, onClick = { nav.navigate(Routes.details(it)) }, onBack = { nav.popBackStack() })
        }
        composable(
            Routes.DETAILS,
            arguments = listOf(navArgument("kioskId") { type = NavType.StringType })
        ) { b ->
            KioskDetailsScreen(
                vm = vm,
                id = b.arguments?.getString("kioskId") ?: "",
                onDirections = { nav.navigate(Routes.directions(it)) },
                onBack = { nav.popBackStack() }
            )
        }
        composable(
            Routes.DIRECTIONS,
            arguments = listOf(navArgument("kioskId") { type = NavType.StringType })
        ) { b ->
            DirectionsMapScreen(vm, b.arguments?.getString("kioskId") ?: "") {
                nav.popBackStack()
            }
        }

    }
}
