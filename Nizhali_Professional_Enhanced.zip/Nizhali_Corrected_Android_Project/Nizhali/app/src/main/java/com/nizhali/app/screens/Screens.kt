package com.nizhali.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nizhali.app.localization.*
import com.nizhali.app.model.*
import com.nizhali.app.state.AppViewModel
import com.nizhali.app.ui.theme.*

@Composable fun SplashScreen(onStart:()->Unit){
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(TealDark,TealPrimary))),contentAlignment=Alignment.Center){
        Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(32.dp)){
            Surface(shape=RoundedCornerShape(28.dp),color=SurfaceWhite.copy(alpha=.15f)){Text("🌿",fontSize=58.sp,modifier=Modifier.padding(20.dp))}
            Spacer(Modifier.height(20.dp));Text("NIZHALI",color=SurfaceWhite,fontSize=42.sp,fontWeight=FontWeight.ExtraBold)
            Text("Care • Access • Dignity",color=SurfaceWhite.copy(.9f));Text("அனைவருக்கும் எளிதில் அணுகக்கூடிய பராமரிப்பு",color=SurfaceWhite.copy(.75f),textAlign=TextAlign.Center)
            Spacer(Modifier.height(44.dp));Button(onStart,Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){Text("Get Started  →",fontSize=16.sp)}
        }
    }
}

@Composable fun LanguageSelectionScreen(onChosen:(AppLanguage)->Unit){
    Column(Modifier.fillMaxSize().background(SandBackground).padding(24.dp),verticalArrangement=Arrangement.Center){
        Text("Welcome to Nizhali",fontSize=30.sp,fontWeight=FontWeight.Bold);Text("Choose your preferred language",color=MutedText);Spacer(Modifier.height(8.dp));Text("உங்கள் மொழியைத் தேர்ந்தெடுக்கவும்",color=MutedText)
        Spacer(Modifier.height(32.dp));LanguageCard("🇬🇧","English","Continue in English"){onChosen(AppLanguage.ENGLISH)};Spacer(Modifier.height(14.dp));LanguageCard("தமிழ்","தமிழ்","தமிழில் தொடரவும்"){onChosen(AppLanguage.TAMIL)}
    }
}
@Composable private fun LanguageCard(icon:String,title:String,sub:String,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable(onClick=onClick),shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(20.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=28.sp);Spacer(Modifier.width(16.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,fontSize=18.sp);Text(sub,color=MutedText,fontSize=13.sp)};Text("›",fontSize=28.sp)}}}

@Composable fun HomeScreen(vm:AppViewModel,onFind:()->Unit,onView:(String)->Unit,onLang:()->Unit,onFavorites:()->Unit){
    val s=stringsFor(vm.language);val k=vm.nearestKiosk()?:return
    Column(Modifier.fillMaxSize().background(SandBackground).verticalScroll(rememberScrollState()).padding(20.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("🌿 NIZHALI",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Smart access. Simple care.",color=MutedText,fontSize=13.sp)};Row{TextButton(onLang){Text(if(vm.language==AppLanguage.ENGLISH)"தமிழ்" else "EN")};TextButton(onFavorites){Text("♡")}}}
        Spacer(Modifier.height(24.dp));Text("Good to see you",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Find a nearby Nizhali kiosk instantly.",color=MutedText)
        Spacer(Modifier.height(22.dp));Text(s.nearestKiosk,fontWeight=FontWeight.Bold,fontSize=16.sp);Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=SurfaceWhite),elevation=CardDefaults.cardElevation(4.dp)){Column(Modifier.padding(20.dp)){Text("📍 ${k.name(vm.language)}",fontSize=19.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text(k.location(vm.language),color=MutedText);Spacer(Modifier.height(14.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){AssistChip(onClick={},label={Text("${k.distanceKm} ${s.kmAway}")});AssistChip(onClick={},label={Text("${statusEmoji(k.status)} ${statusLabel(k.status,s)}")})};Spacer(Modifier.height(10.dp));Text("📦 ${k.stock} ${s.padsAvailable}",fontWeight=FontWeight.Medium);Spacer(Modifier.height(14.dp));Button({onView(k.id)},Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("View kiosk details →")}}}
        Spacer(Modifier.height(20.dp));Text("Quick actions",fontWeight=FontWeight.Bold,fontSize=17.sp);Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickAction("🗺️","Nearby",Modifier.weight(1f),onFind);QuickAction("⭐","Saved",Modifier.weight(1f),onFavorites);QuickAction("🔔","Alerts",Modifier.weight(1f)){}}
        Spacer(Modifier.height(24.dp));Button(onFind,Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){Text(s.findNearbyKiosks)}
        Spacer(Modifier.height(10.dp));Text("Status information is simulated for the prototype demo.",fontSize=12.sp,color=MutedText,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
    }
}
@Composable private fun QuickAction(icon:String,label:String,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(vertical=16.dp).fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=22.sp);Text(label,fontSize=12.sp)}}}

@Composable fun NearbyKiosksScreen(vm:AppViewModel,onClick:(String)->Unit,onBack:()->Unit){val s=stringsFor(vm.language);Column(Modifier.fillMaxSize().background(SandBackground).padding(16.dp)){TextButton(onBack){Text("← ${s.back}")};Text(s.nearbyKiosksTitle,fontSize=26.sp,fontWeight=FontWeight.Bold);Text("Choose the kiosk that works best for you",color=MutedText);Spacer(Modifier.height(14.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){items(vm.kiosks.sortedBy{it.distanceKm}){k->Card(Modifier.fillMaxWidth().clickable{onClick(k.id)},shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(14.dp),color=TealTint){Text("📍",fontSize=24.sp,modifier=Modifier.padding(12.dp))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(k.name(vm.language),fontWeight=FontWeight.Bold);Text("${k.distanceKm} ${s.kmAway} • ${k.stock} ${s.padsWord}",color=MutedText,fontSize=13.sp);Text("${statusEmoji(k.status)} ${statusLabel(k.status,s)}",fontSize=13.sp)};Text("›",fontSize=24.sp)}}}}}}

@Composable fun KioskDetailsScreen(vm:AppViewModel,id:String,onDirections:(String)->Unit,onBack:()->Unit){val s=stringsFor(vm.language);val k=vm.kioskById(id)?:return;Column(Modifier.fillMaxSize().background(SandBackground).verticalScroll(rememberScrollState()).padding(20.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){TextButton(onBack){Text("← ${s.back}")};TextButton({vm.toggleFavorite(id)}){Text(if(vm.isFavorite(id))"★ Saved" else "☆ Save")}};Text(k.name(vm.language),fontSize=25.sp,fontWeight=FontWeight.Bold);Text("📍 ${k.location(vm.language)} • ${k.distanceKm} ${s.kmAway}",color=MutedText);Spacer(Modifier.height(20.dp));StatusHero(k,s);Spacer(Modifier.height(14.dp));InfoCard("📦 ${s.padAvailability}","${k.stock} / ${k.capacity} ${s.padsWord}"){LinearProgressIndicator(progress={k.stock.toFloat()/k.capacity},modifier=Modifier.fillMaxWidth().padding(top=8.dp))};Spacer(Modifier.height(12.dp));InfoCard("⚡ ${s.powerStatus}",if(k.powerHealthy)"🟢 ${s.healthy}" else "🔴 ${s.unhealthy}"){};Spacer(Modifier.height(12.dp));InfoCard("🔧 ${s.machineStatus}","${statusEmoji(k.status)} ${statusLabel(k.status,s)}"){};Spacer(Modifier.height(20.dp));Button({onDirections(k.id)},Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){Text("🗺️ ${s.getDirections}")};Spacer(Modifier.height(10.dp));OutlinedButton({vm.simulateNextUpdate(k.id)},Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Text("🔄 ${s.simulateUpdate}")};Spacer(Modifier.height(12.dp));Text("Demo mode: stock and machine data are simulated in real time.",fontSize=12.sp,color=MutedText)}}
@Composable private fun StatusHero(k:Kiosk,s:UiStrings){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=TealTint)){Column(Modifier.padding(20.dp)){Text("CURRENT STATUS",fontSize=11.sp,fontWeight=FontWeight.Bold,color=MutedText);Spacer(Modifier.height(6.dp));Text("${statusEmoji(k.status)} ${statusLabel(k.status,s)}",fontSize=22.sp,fontWeight=FontWeight.Bold)}}}
@Composable private fun InfoCard(title:String,value:String,extra:@Composable()->Unit){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(title,color=MutedText,fontSize=13.sp);Text(value,fontWeight=FontWeight.SemiBold,fontSize=17.sp);extra()}}}

@Composable fun FavoritesScreen(vm:AppViewModel,onClick:(String)->Unit,onBack:()->Unit){val list=vm.kiosks.filter{vm.isFavorite(it.id)};Column(Modifier.fillMaxSize().background(SandBackground).padding(20.dp)){TextButton(onBack){Text("← Back")};Text("Saved kiosks",fontSize=26.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp));if(list.isEmpty())Box(Modifier.fillMaxWidth().padding(top=80.dp),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("☆",fontSize=50.sp);Text("No saved kiosks yet",fontWeight=FontWeight.Bold);Text("Save a kiosk for quick access",color=MutedText)}} else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(list){k->Card(Modifier.fillMaxWidth().clickable{onClick(k.id)},shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(k.name(vm.language),fontWeight=FontWeight.Bold);Text("${k.distanceKm} km • ${k.stock} pads",color=MutedText)}}}}}}
