package com.nizhali.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nizhali.app.navigation.NizhaliNavHost
import com.nizhali.app.state.AppViewModel
import com.nizhali.app.ui.theme.NizhaliTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NizhaliTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NizhaliNavHost(viewModel<AppViewModel>())
                }
            }
        }
    }
}
