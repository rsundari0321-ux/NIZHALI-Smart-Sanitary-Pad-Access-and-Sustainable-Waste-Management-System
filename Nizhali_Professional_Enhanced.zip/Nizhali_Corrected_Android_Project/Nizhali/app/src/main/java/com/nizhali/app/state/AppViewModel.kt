package com.nizhali.app.state

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import com.nizhali.app.data.MockData
import com.nizhali.app.model.*

class AppViewModel: ViewModel() {
    var language by mutableStateOf(AppLanguage.ENGLISH); private set
    val kiosks = mutableStateListOf<Kiosk>().apply { addAll(MockData.initialKiosks()) }
    val favorites = mutableStateListOf<String>()

    fun setLanguage(l: AppLanguage) { language = l }
    fun nearestKiosk() = kiosks.minByOrNull { it.distanceKm }
    fun kioskById(id: String) = kiosks.find { it.id == id }
    fun toggleFavorite(id: String) { if (favorites.contains(id)) favorites.remove(id) else favorites.add(id) }
    fun isFavorite(id: String) = favorites.contains(id)

    fun simulateNextUpdate(id: String) {
        val i = kiosks.indexOfFirst { it.id == id }; if (i < 0) return
        val k = kiosks[i]; if (k.status == KioskStatus.MAINTENANCE) return
        val stock = (k.stock - 6).coerceAtLeast(0)
        val status = when { stock == 0 -> KioskStatus.OUT_OF_STOCK; stock <= 6 -> KioskStatus.LOW_STOCK; else -> KioskStatus.OPERATIONAL }
        kiosks[i] = k.copy(stock = stock, status = status)
    }
}
