# Nizhali — Corrected Android Studio Project

This project was corrected to use:

- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- Kotlin: 2.0.21
- JDK: 17
- Jetpack Compose

## IMPORTANT

Do NOT use Gradle 9.3.0 for this project.

### Recommended Android Studio setup

1. Open the `Nizhali` folder.
2. Go to **File > Settings > Build, Execution, Deployment > Build Tools > Gradle**.
3. Set **Gradle JDK** to **Embedded JDK (17)**.
4. If Android Studio asks for a Gradle version, use **Gradle 8.7**.
5. Let the project sync.

### If your network has trouble downloading Gradle

Download the official `gradle-8.7-bin.zip`, extract it, and in Android Studio's Gradle settings select the extracted `gradle-8.7` folder as the local Gradle installation.

The project dependencies still require internet access to Google Maven and Maven Central during the first sync.
