# EcoFlow Digital Twin Simulator

Open `index.html` in a modern browser.

## Demo
1. Click **Start Full Demo**.
2. Watch the bottle move through detection, verification, decision, dispensing, collection and completion.
3. Try the scenario buttons when the simulator is idle:
   - Valid Bottle
   - Invalid / Underweight
   - Low Battery
   - Low Solar
   - Tamper Fault
4. Use Reset before switching scenarios or starting another run.

All sensor and energy values are explicitly simulated representations of the proposed EcoFlow hardware system.

## Language
Click the 🌐 button in the header to switch the entire simulator — kiosk labels, sensor readings, timeline, scenarios, notices — between English and Tamil (தமிழ்). Built for a rural-women-facing use case, so Tamil is a full, first-class translation rather than a couple of stray labels. The toggle is disabled mid-simulation to avoid swapping text under a running animation; switch languages while idle or after a run completes.

## Voice announcement
When the servo dispenses a pad, the simulator speaks "Pad dispensed" (or "நாப்கின் வழங்கப்பட்டது" in Tamil) out loud using the browser's built-in SpeechSynthesis API — no audio files, no network call, so it still works fully offline as long as the device has a matching TTS voice installed. It's tied to the same Sound ON/OFF toggle as the sound effects.

## Sound design
All effects are synthesized live with the Web Audio API — no audio files, so the simulator still runs fully offline. Each kiosk event now has its own layered sound rather than a generic beep:
- **Insert** — soft whoosh + padded thunk as the bottle lands on the sensor platform
- **Detect / Verify** — crisp IR blips, then a ratcheting scale-tick sequence as the load cell settles
- **Accept** — a brief major-triad chime with a light reverb tail
- **Reject** — a two-hit electronic buzzer (tremolo square wave), distinct from the accept chime
- **Servo** — a swept, vibrato'd motor "whirr" that seats with a hard click
- **Dispense** — a paper/plastic slide followed by a soft landing tick
- **Collect** — a bright clink, a low hollow thud, and a faint rattle as the bottle drops into the bin
- **Success** — a four-note ascending bell run with reverb and a shimmer overtone
- **Fault / Tamper** — an urgent two-tone alarm siren, deliberately harsher than the reject buzzer
- **Reset** — a gentle descending power-down sweep

A soft limiter on the master bus keeps layered sounds (e.g. the success chime + its reverb tail) from ever clipping.
